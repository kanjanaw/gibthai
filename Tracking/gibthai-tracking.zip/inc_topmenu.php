<div class="container-fluid bg-white" style="border-bottom: 1px solid #E0E0E0;">
    <div class="container">
    <nav class="navbar">
        <a class="navbar-brand" href="#">
            <img src="images/icon-transparent.png" width="80" alt="">
            <span class="header-title font-weight-600">&nbsp; ระบบขอรับบริการสอบเทียบและตรวจเช็คสถานะงาน</span>
        </a>
    </nav>
    </div>
</div>



         