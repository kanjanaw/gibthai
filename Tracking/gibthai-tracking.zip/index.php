<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><?php require('inc_header.php'); ?>
</head>
<body>
<?php require('inc_topmenu.php'); ?>

<div class="">
    <div class="container">
    <div class="row">
        <div class="col-6 text-light p-5 bg-black-333">
            <h3 class="font-weight-700">บริการสอบเทียบเครื่องมือวัด</h3>
            <p>ได้รับการรับรองมาตรฐานห้องปฎิบัติการสอบเทียบ ISO/IEC 17025 ของเครื่องมือ ไมโครไปเปต ขอบข่ายที่ได้รับการรับรอง 0.1 ul. - 10 ml.</p>
            <p>ห้องปฎิบัติการเป็นห้องที่สมบูรณ์แบบ ทั้งเครื่องมือ อุปกรณ์ที่ทันสมัย ตลอดจนบุคลากรที่มีคุณภาพ มีความรู้และประสบการณ์ พร้อมให้บริการสอบเทียบอย่างเต็มประสิทธิภาพ และบริการหลังการสอบเทียบ รวมทั้งการการันตีคุณภาพงานสอบสอบเทียบ</p>
            <a href="form-request-service.php"><button type="button" class="btn btn-green-00">ฟอร์มขอใช้บริการสอบเทียบ</button></a>
        </div>
        <div class="col-6 p-5">
            <h3 class="font-weight-700">ติดตามสถานะการบริการสอบเทียบ</h3>
            <form class="d-flex">
                <input class="form-control form-tracking" type="search" placeholder="กรอก Request ID" aria-label="Tracking">
                <button class="btn btn-green-00 px-5" type="submit">ติดตาม</button>
            </form>
        </div>
        <div class="col-6 p-5 d-flex justify-content-center align-items-center">
           <img src="images/cer1.jpg" alt="" class="img-fluid" width="45%">
           <img src="images/nc.jpg" alt=""  class="img-fluid" width="45%">
        </div>
        <div class="col-6 p-5 bg-img-green" >
        </div>
    </div>
    </div>
    
</div>

<?php require('inc_footer.php'); ?>
</body>
</html>